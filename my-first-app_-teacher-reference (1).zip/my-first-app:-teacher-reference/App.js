import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';


class AnyColorButton extends Component {
  displayAlert=function(){
    alert(" This is an alert box.");
  }
  render(){
    return(
      <Button color= {this.props.myColor} title={this.props.title} onPress = {this.displayAlert}/>
    )
  }
}

export default class App extends Component {
  render() {
    return (
      <View style={{marginTop: 100}}>
        <AnyColorButton myColor = "red" title = "Press me"/>
        <Text>My First React Component</Text>
      </View>
    );
  }
}